<?php
/**
* @version $Id: radius.php $
* @package Joomla
* @subpackage JFramework
* @copyright Copyright (C) 2012 - 2012 Open Source Matters. All rights reserved.
* @license GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*
* Joomla Radius SecurePass plugin
*
* @author Luca Sciortino <luca.sciortino@waupau.org>
* @package Joomla
* @subpackage JFramework
* @since 1.5
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.plugin.plugin');

// Radius Port 
define("RADIUS_PORT", "1812", true);

// The shared secret is common for all zone
// The same database


class plgAuthenticationRadius extends JPlugin
{

/**
* This method should handle any authentication and report back to the subject
*
* @access	public
* @param	string	$username	Username for authentication
* @param	string	$password	Password for authentication
* @param	object	$response	Authentication response object
* @return	boolean
* @since 1.5
*/
function onUserAuthenticate( $credentials, $options, &$response )
{
	jimport('joomla.user.helper');

        // Joomla does not like blank passwords
        if (empty($credentials['password']))
        {
        	$response->status = JAUTHENTICATE_STATUS_FAILURE;
                $response->error_message = 'Empty password not allowed';
                return false;
        }
    		
function do_authentication ($host,$port,$sharedsecret,$username,$password,$sec,$usec,&$response) {
$data = "";
$error = false;
$ip = gethostbyname($_SERVER['SERVER_ADDR']);
$code = pack("C",1);
$identifier=pack("C",rand()%256);
$authenticator = pack("CCCCCCCCCCCCCCCC",
1+rand()%255, 1+rand()%255, 1+rand()%255, 1+rand()%255,
1+rand()%255, 1+rand()%255, 1+rand()%255, 1+rand()%255,
1+rand()%255, 1+rand()%255, 1+rand()%255, 1+rand()%255,
1+rand()%255, 1+rand()%255, 1+rand()%255, 1+rand()%255);
$attributes=pack("C",1).pack("C",strlen($username)+2).$username;
$md5=pack("H*",md5($sharedsecret.$authenticator));
$output="";
$pad=16-(strlen($password)%16);
for ($i=0;$i<$pad;$i++) {
	$password .= "\0";
}
  	for ($i=0;$i<strlen($password)/16;$i++) {
  		$block = substr($password,$i*16,16) ^ $md5; 
  		$output .= $block;
  		$md5=pack("H*",md5($sharedsecret.$block));
  	}
$attributes.=pack("C",2).pack("C",strlen($output)+2).$output;
$nasip=explode(".",$ip);
$attributes.=pack("CCCCCC",4,6,$nasip[0],$nasip[1],$nasip[2],$nasip[3]);
$attributes.=pack("CCCCCC",5,6,0,0,0,0);
$l = 20+strlen($attributes);
$length = pack("CC",floor($l/256),$l%256);
$data=$code.$identifier.$length.$authenticator.$attributes;
  		
if (false == ($sock=socket_create(AF_INET,SOCK_DGRAM,SOL_UDP))) {
	$error = "Couldn't create socket, error code is: ".socket_last_error().",error message is: ".socket_strerror(socket_last_error());
} else {
	if (false == (socket_connect($sock, $host, $port))) {
		$error = "Couldn't connect to socket, error code is: ".socket_last_error().",error message is: ".socket_strerror(socket_last_error());
		socket_close($sock);
	} else {
	if (false == (socket_write ($sock, $data, strlen ($data)))) {
		$error = "Couldn't write to socket, error code is: ".socket_last_error().",error message is: ".socket_strerror(socket_last_error());
		socket_close($sock);
	} else {
	if ($sec+$usec>0) {
		socket_set_option($sock,SOL_SOCKET, SO_RCVTIMEO, array("sec"=>$sec, "usec"=>$usec));
  			}
  		if (false == ($read=socket_read($sock,2048))) {
  			$error = "Couldn't read from socket, error code is: ".socket_last_error().",error message is: ".socket_strerror(socket_last_error());
  			socket_close($sock);
  		} else {
  			if(ord(mb_substr($read,0,1)) == 2) {
 				$response->status = JAUTHENTICATE_STATUS_SUCCESS;
  			} else {
  				$error = 'Authentication failed!';
  	}
  		}
  			}	
}
}
if ($error) {
	$response->status = JAUTHENTICATE_STATUS_FAILURE;
  	$response->error_message = $error;
}
 	return true;
}
		
$retval = do_authentication($this->params->get('host'),RADIUS_PORT,$this->params->get('secret'),$credentials['username'],$credentials['password'],$this->params->get('sec'),$this->params->get('usec'),$response);
if ($response->error_message != 'Authentication failed!' and $response->status != JAUTHENTICATE_STATUS_SUCCESS and $this->params->get('sec_host') ) {
	$retval = do_authentication($this->params->get('sec_host'),RADIUS_PORT,$this->params->get('secret'),$credentials['username'],$credentials['password'],$this->params->get('sec'),$this->params->get('usec'),$response);
} 
return $response;
}
}
?>
